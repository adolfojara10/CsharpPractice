﻿using SingleResponsability;

StudentRepository studentRepository = new();
studentRepository.Export();
Console.WriteLine("Proceso Completado");