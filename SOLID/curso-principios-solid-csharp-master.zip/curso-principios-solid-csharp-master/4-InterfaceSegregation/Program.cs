﻿using InterfaceSegregation;

new Developer().Develop();