# Principios SOLID en C# curso
Para iniciar el curso debes usar el código de la rama master o de la rama 0-codigobase